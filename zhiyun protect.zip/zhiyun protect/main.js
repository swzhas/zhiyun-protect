import App from './App.vue'
import auth from './utils/auth'

// #ifndef VUE3
import Vue from 'vue'
Vue.config.productionTip = false
App.mpType = 'app'
const app = new Vue({
  ...App
})
app.$mount()
// #endif

// #ifdef VUE3
import { createSSRApp } from 'vue'
export function createApp() {
  const app = createSSRApp(App)
  return {
    app
  }
}
// #endif

// 添加全局路由拦截
uni.addInterceptor('navigateTo', {
  invoke(args) {
    const publicPages = ['/pages/login/login']
    const isLoginPage = publicPages.some(page => args.url.includes(page))
    
    if (!auth.isAuthenticated() && !isLoginPage) {
      uni.redirectTo({ url: '/pages/login/login' })
      return false
    }
    return true
  }
})

// 拦截微信小程序原生后退按钮
// #ifdef MP-WEIXIN
uni.onAppRoute((route) => {
  if (!auth.isAuthenticated() && route.path !== 'pages/login/login') {
    uni.redirectTo({ url: '/pages/login/login' })
  }
})
// #endif