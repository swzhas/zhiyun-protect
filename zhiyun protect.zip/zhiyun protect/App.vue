<template>	<view class="app-container">
	  <!-- 顶部导航栏（优化后） -->
	  <view class="global-nav">
		<text class="nav-title">{{ navTitle }}</text>
	  </view>
  
	  <!-- 页面内容 -->
	  <view class="page-content">
		<router-view />
	  </view>
  
	  <!-- 底部Tabbar（调整顺序后） -->
	  <view class="global-tabbar">
		<view 
		  v-for="(item, index) in tabbarList" 
		  :key="index" 
		  class="tabbar-item"
		  :class="{ 'active': currentTab === index }"
		  @click="switchTab(index, item.pagePath)"
		>
		  <image :src="currentTab === index ? item.selectedIconPath : item.iconPath" class="tabbar-icon" />
		  <text class="tabbar-text">{{ item.text }}</text>
		</view>
	  </view>
  
	  <!-- 全局弹窗 -->
	  <uni-popup ref="popup" type="message">
		<uni-popup-message :type="popupType" :message="popupMessage" :duration="2000"></uni-popup-message>
	  </uni-popup>
	</view>
  </template>
  
  <script>
  export default {
	data() {
	  return {
		// Tabbar配置（调整顺序：将"咨询"和"搜索"互换）
		tabbarList: [
		  {
			text: "首页",
			pagePath: "/pages/tabbar/tabbar-1/tabbar-1",
			iconPath: "/static/img/tabbar/home.png",
			selectedIconPath: "/static/img/tabbar/homeactive.png",
		  },
		  {
			text: "搜索",  // 原"咨询"位置改为"搜索"
			pagePath: "/pages/tabbar/tabbar-4/tabbar-4",
			iconPath: "/static/img/tabbar/guanzhu.png",
			selectedIconPath: "/static/img/tabbar/guanzhuactive.png",
		  },
		  {
			text: "记录",
			pagePath: "/pages/tabbar/tabbar-3/tabbar-3",
			iconPath: "/static/img/tabbar/add.png",
			selectedIconPath: "/static/img/tabbar/addactive.png",
		  },
		  {
			text: "咨询",  // 原"搜索"位置改为"咨询"
			pagePath: "/pages/tabbar/tabbar-2/tabbar-2",
			iconPath: "/static/img/tabbar/news.png",
			selectedIconPath: "/static/img/tabbar/newsactive.png",
		  },
		  {
			text: "我的",
			pagePath: "/pages/tabbar/tabbar-5/tabbar-5",
			iconPath: "/static/img/tabbar/me.png",
			selectedIconPath: "/static/img/tabbar/meactive.png",
		  },
		],
		currentTab: 0,
		showNav: true,
		navTitle: "智云防护咨询小助手",
		popupMessage: "",
		popupType: "success",
	  };
	},
	methods: {
	  switchTab(index, path) {
		this.currentTab = index;
		uni.switchTab({
		  url: path,
		});
	  },
	  showPopup(message, type = "success") {
		this.popupMessage = message;
		this.popupType = type;
		this.$refs.popup.open();
	  },
	},
  };
  </script>
  
  <style>
  /* 优化后的顶部导航栏样式 */
  .global-nav {
	height: 80rpx;
	background: linear-gradient(90deg, #1E90FF 0%, #00BFFF 100%); /* 渐变背景 */
	color: #fff;
	display: flex;
	justify-content: center;
	align-items: center;
	box-shadow: 0 4rpx 12rpx rgba(25, 118, 210, 0.2); /* 添加阴影 */
  }
  .nav-title {
	font-size: 34rpx;
	font-weight: bold;
	text-shadow: 0 2rpx 4rpx rgba(0, 0, 0, 0.1); /* 文字阴影 */
  }
  
  /* 其他原有样式保持不变 */
  .app-container {
	display: flex;
	flex-direction: column;
	height: 100vh;
	background-color: #f8f8f8;
  }
  .page-content {
	flex: 1;
	overflow-y: auto;
  }
  .global-tabbar {
	height: 100rpx;
	background-color: #fff;
	display: flex;
	border-top: 1rpx solid #eee;
  }
  .tabbar-item {
	flex: 1;
	display: flex;
	flex-direction: column;
	justify-content: center;
	align-items: center;
  }
  .tabbar-icon {
	width: 50rpx;
	height: 50rpx;
	margin-bottom: 6rpx;
  }
  .tabbar-text {
	font-size: 22rpx;
	color: #666;
  }
  .tabbar-item.active .tabbar-text {
	color: #1E90FF;
  }
  </style>