// utils/record.js
import CryptoJS from 'crypto-js'

const STORAGE_KEY = 'encrypted_fraud_records'

// 改用更通用的密钥生成方式（兼容所有平台）
function getSecretKey() {
  // 微信小程序用系统信息+随机数，其他平台用设备信息
  if (uni.getSystemInfoSync().platform === 'devtools') {
    return 'dev_' + Math.random().toString(36).substring(2)
  }
  return (uni.getSystemInfoSync().system + '__' + Date.now()).slice(0, 32)
}

const SECRET_KEY = getSecretKey()

export default {
  // 添加新记录
  add(record) {
    const records = this.getAll()
    record.id = Date.now()
    record.createdAt = new Date().toISOString()
    records.unshift(record)
    this.save(records)
    return record
  },

  // 获取全部记录
  getAll() {
    try {
      const encrypted = uni.getStorageSync(STORAGE_KEY)
      if (!encrypted) return []
      
      const bytes = CryptoJS.AES.decrypt(encrypted, SECRET_KEY)
      const decrypted = bytes.toString(CryptoJS.enc.Utf8)
      return JSON.parse(decrypted) || []
    } catch (error) {
      console.error('记录解密失败:', error)
      return []
    }
  },

  // 保存记录
  save(records) {
    const encrypted = CryptoJS.AES.encrypt(
      JSON.stringify(records),
      SECRET_KEY
    ).toString()
    uni.setStorageSync(STORAGE_KEY, encrypted)
  },

  // 其他方法保持不变...
  deleteById(id) {
    const records = this.getAll().filter(item => item.id !== id)
    this.save(records)
  },

  clearAll() {
    uni.removeStorageSync(STORAGE_KEY)
  }
}