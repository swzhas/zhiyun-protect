const STORAGE_KEY = 'user_data'

export default {
  // 保存用户信息（注册/登录时调用）
  setUser(user) {
    const userData = {
      ...user,
      loginTime: new Date().getTime()
    }
    uni.setStorageSync(STORAGE_KEY, JSON.stringify(userData))
  },

  // 获取完整用户信息
  getUser() {
    const data = uni.getStorageSync(STORAGE_KEY)
    return data ? JSON.parse(data) : null
  },

  // 清除登录状态
  clearUser() {
    uni.removeStorageSync(STORAGE_KEY)
  },

  // 检查登录状态
  isAuthenticated() {
    return !!this.getUser()
  }
}