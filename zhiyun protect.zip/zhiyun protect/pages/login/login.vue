<template>
    <view class="login-bg">
      <!-- 顶部波浪装饰 -->
      <view class="wave-bg"></view>
  
      <!-- 登录卡片 -->
      <view class="login-card">
        <!-- Logo -->
        <image src="/static/img/logo.png" class="logo" mode="aspectFit" />
  
        <!-- 标题 -->
        <text class="title">智云防护</text>
        <text class="subtitle">安全咨询 · 诈骗防护</text>
  
        <!-- 登录表单 -->
        <view v-if="isLoginMode" class="form-container">
          <view class="input-group">
            <text class="input-label">用户名</text>
            <input 
              v-model="loginForm.username" 
              placeholder="请输入用户名" 
              class="input-field"
              @focus="focusInput('username')"
            />
            <view class="underline" :class="{ 'active': activeField === 'username' }"></view>
          </view>
  
          <view class="input-group">
            <text class="input-label">密码</text>
            <input 
              v-model="loginForm.password" 
              placeholder="请输入密码" 
              password 
              class="input-field"
              @focus="focusInput('password')"
            />
            <view class="underline" :class="{ 'active': activeField === 'password' }"></view>
          </view>
  
          <button 
            @click="handleLogin" 
            class="submit-btn"
            :disabled="!loginForm.username || !loginForm.password"
          >
            登录
          </button>
  
          <text class="switch-text" @click="switchMode">
            没有账号？<text class="highlight">立即注册</text>
          </text>
        </view>
  
        <!-- 注册表单 -->
        <view v-else class="form-container">
          <view class="input-group">
            <text class="input-label">用户名</text>
            <input 
              v-model="registerForm.username" 
              placeholder="4-16位字母或数字" 
              class="input-field"
              @focus="focusInput('regUsername')"
            />
            <view class="underline" :class="{ 'active': activeField === 'regUsername' }"></view>
          </view>
  
          <view class="input-group">
            <text class="input-label">密码</text>
            <input 
              v-model="registerForm.password" 
              placeholder="6-18位字符" 
              password 
              class="input-field"
              @focus="focusInput('regPassword')"
            />
            <view class="underline" :class="{ 'active': activeField === 'regPassword' }"></view>
          </view>
  
          <view class="input-group">
            <text class="input-label">确认密码</text>
            <input 
              v-model="registerForm.confirmPassword" 
              placeholder="再次输入密码" 
              password 
              class="input-field"
              @focus="focusInput('regConfirm')"
            />
            <view class="underline" :class="{ 'active': activeField === 'regConfirm' }"></view>
          </view>
  
          <button 
            @click="handleRegister" 
            class="submit-btn"
            :disabled="!isRegisterValid"
          >
            注册
          </button>
  
          <text class="switch-text" @click="switchMode">
            已有账号？<text class="highlight">立即登录</text>
          </text>
        </view>
      </view>
  
      <!-- 底部装饰 -->
      <view class="decor-circle"></view>
    </view>
  </template>
  
  <script>
  import auth from '@/utils/auth'
  
  export default {
    data() {
      return {
        isLoginMode: true,
        activeField: '',
        loginForm: {
          username: '',
          password: ''
        },
        registerForm: {
          username: '',
          password: '',
          confirmPassword: ''
        }
      }
    },
    computed: {
      isRegisterValid() {
        return (
          this.registerForm.username &&
          this.registerForm.password &&
          this.registerForm.password === this.registerForm.confirmPassword
        )
      }
    },
    methods: {
      focusInput(field) {
        this.activeField = field
      },
      switchMode() {
        this.isLoginMode = !this.isLoginMode
        this.activeField = ''
      },
      async handleLogin() {
        if (!this.loginForm.username) {
          uni.showToast({ title: '请输入用户名', icon: 'none' })
          return
        }
        if (!this.loginForm.password) {
          uni.showToast({ title: '请输入密码', icon: 'none' })
          return
        }
  
        // 模拟登录成功
        auth.setUser({
          username: this.loginForm.username,
          loginTime: new Date().getTime()
        })
        
        uni.reLaunch({ url: '/pages/tabbar/tabbar-1/tabbar-1' })
      },
      async handleRegister() {
        if (this.registerForm.password !== this.registerForm.confirmPassword) {
          uni.showToast({ title: '两次密码不一致', icon: 'none' })
          return
        }
  
        // 模拟注册成功
        auth.setUser({
          username: this.registerForm.username,
          loginTime: new Date().getTime()
        })
        
        uni.showToast({ title: '注册成功', icon: 'success' })
        setTimeout(() => {
          uni.reLaunch({ url: '/pages/tabbar/tabbar-1/tabbar-1' })
        }, 1500)
      }
    }
  }
  </script>
  
  <style>
  .login-bg {
    height: 100vh;
    background: linear-gradient(to bottom, #f5f9ff 0%, #e6f1ff 100%);
    display: flex;
    flex-direction: column;
    align-items: center;
    position: relative;
    overflow: hidden;
  }
  
  .wave-bg {
    width: 100%;
    height: 200rpx;
    background: linear-gradient(90deg, #1E90FF 0%, #3CB0FD 100%);
    border-radius: 0 0 50% 50% / 0 0 100% 100%;
    position: absolute;
    top: 0;
  }
  
  .login-card {
    width: 86%;
    margin-top: 180rpx;
    padding: 60rpx 40rpx;
    background: #fff;
    border-radius: 24rpx;
    box-shadow: 0 10rpx 30rpx rgba(30, 144, 255, 0.1);
    z-index: 2;
  }
  
  .logo {
    width: 120rpx;
    height: 120rpx;
    display: block;
    margin: 0 auto 20rpx;
  }
  
  .title {
    display: block;
    text-align: center;
    font-size: 42rpx;
    color: #1E90FF;
    font-weight: bold;
    margin-bottom: 8rpx;
  }
  
  .subtitle {
    display: block;
    text-align: center;
    font-size: 28rpx;
    color: #5c9ded;
    margin-bottom: 60rpx;
  }
  
  .form-container {
    margin-top: 40rpx;
  }
  
  .input-group {
    margin-bottom: 50rpx;
    position: relative;
  }
  
  .input-label {
    display: block;
    font-size: 28rpx;
    color: #1976d2;
    margin-bottom: 16rpx;
    font-weight: 500;
  }
  
  .input-field {
    width: 100%;
    height: 80rpx;
    font-size: 30rpx;
    padding: 0 10rpx;
    border: none;
    border-bottom: 2rpx solid #e0e0e0;
    background: transparent;
  }
  
  .underline {
    height: 2rpx;
    width: 0;
    background: #1E90FF;
    position: absolute;
    bottom: 0;
    left: 0;
    transition: all 0.3s;
  }
  
  .underline.active {
    width: 100%;
  }
  
  .submit-btn {
    width: 100%;
    height: 90rpx;
    line-height: 90rpx;
    background: linear-gradient(90deg, #1E90FF, #3CB0FD);
    color: white;
    border-radius: 12rpx;
    font-size: 32rpx;
    font-weight: 500;
    margin-top: 20rpx;
    border: none;
  }
  
  .submit-btn[disabled] {
    opacity: 0.6;
  }
  
  .switch-text {
    display: block;
    text-align: center;
    color: #999;
    font-size: 28rpx;
    margin-top: 40rpx;
  }
  
  .highlight {
    color: #1E90FF;
    font-weight: 500;
  }
  
  .decor-circle {
    width: 400rpx;
    height: 400rpx;
    background: rgba(30, 144, 255, 0.05);
    border-radius: 50%;
    position: absolute;
    bottom: -150rpx;
    right: -150rpx;
    z-index: 1;
  }
  </style>