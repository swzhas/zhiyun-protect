<template>
	<view class="search-bg">
	  <view class="search-container">
		<view class="search-header">
		  <!-- 搜索框 -->
		  <view class="search-bar">
			<uni-search-bar
			  v-model="searchKeyword"
			  placeholder="输入关键词搜索"
			  @confirm="handleSearch"
			  @cancel="handleCancel"
			  bgColor="#eaf4ff"
			  cancelButton="auto"
			  :radius="18"
			  :focus-color="'#1976d2'"
			></uni-search-bar>
		  </view>
  
		  <!-- 筛选条件 -->
		  <view class="filter-section">
			<view class="filter-item">
			  <text class="filter-label">地区</text>
			  <picker
				@change="bindRegionChange"
				:range="regionOptions"
				range-key="name"
				class="filter-picker"
			  >
				<view class="picker-text">{{ selectedRegion.name || '全部地区' }}</view>
			  </picker>
			</view>
  
			<view class="filter-item">
			  <text class="filter-label">类型</text>
			  <picker
				@change="bindTypeChange"
				:range="fraudTypes"
				class="filter-picker"
			  >
				<view class="picker-text">{{ selectedType || '全部类型' }}</view>
			  </picker>
			</view>
  
			<view class="filter-item">
			  <text class="filter-label">时间</text>
			  <picker
				mode="date"
				fields="month"
				@change="bindDateChange"
				class="filter-picker"
			  >
				<view class="picker-text">{{ selectedDate || '全部时间' }}</view>
			  </picker>
			</view>
		  </view>
		</view>
  
		<!-- 搜索结果 -->
		<view class="search-results">
		  <view v-if="filteredCases.length === 0" class="empty-tip">
			<text>暂无匹配结果</text>
		  </view>
		  <view v-else>
			<view
			  v-for="(caseItem, index) in filteredCases"
			  :key="index"
			  class="case-card"
			  @click="navigateToDetail(caseItem)"
			>
			  <image :src="caseItem.image" class="case-image" mode="aspectFill"></image>
			  <view class="case-info">
				<text class="case-title">{{ caseItem.title }}</text>
				<view class="case-meta">
				  <text class="case-tag">{{ caseItem.type }}</text>
				  <text class="case-tag case-tag-light">{{ caseItem.region }}</text>
				  <text class="case-tag case-tag-light">{{ caseItem.date }}</text>
				</view>
			  </view>
			</view>
		  </view>
		</view>
	  </view>
	</view>
  </template>
  
  <script>
  export default {
	data() {
	  return {
		searchKeyword: "", // 搜索关键词
		selectedRegion: {}, // 选中地区
		selectedType: "", // 选中类型
		selectedDate: "", // 选中时间
		regionOptions: [
		  { name: "全部地区", value: "" },
		  { name: "北京市", value: "北京市" },
		  { name: "广东省", value: "广东省" },
		  // 其他省份...
		],
		fraudTypes: ["全部类型", "投资诈骗", "电信诈骗", "网络诈骗", "兼职诈骗"],
		cases: [], // 从首页或其他数据源获取案例
		filteredCases: [], // 筛选后的结果
	  };
	},
	mounted() {
	  this.loadCases(); // 加载案例数据
	},
	methods: {
	  // 加载案例数据（模拟）
	  loadCases() {
		this.cases = [
		  {
			title: "“高回报投资”诈骗案",
			type: "投资诈骗",
			region: "广东省深圳市",
			date: "2023-10-15",
			image: "/static/img/cases/case_1.jpg",
		  },
		  {
			title: "“冒充公检法”诈骗案",
			type: "电信诈骗",
			region: "北京市朝阳区",
			date: "2023-09-20",
			image: "/static/img/cases/case_2.jpg"
		  },
		  {
			title: "“虚假中奖”诈骗案",
			type: "网络诈骗",
			region: "上海市浦东区",
			date: "2023-08-05",
			image: "/static/img/cases/case_3.jpg"
		  },
		  {
			title: "“刷单兼职”诈骗案",
			type: "兼职诈骗",
			region: "浙江省杭州市",
			date: "2023-07-12",
			image: "/static/img/cases/case_4.jpg"
		  },
		  {
			title: "“虚假贷款”诈骗案",
			type: "金融诈骗",
			region: "四川省成都市",
			date: "2023-06-30",
			image: "/static/img/cases/case_5.jpg"
		  },
		  {
			title: "“冒充客服退款”诈骗案",
			type: "电商诈骗",
			region: "江苏省南京市",
			date: "2023-05-18",
			image: "/static/img/cases/case_6.jpg"
		  },
		  {
			title: "“虚假慈善募捐”诈骗案",
			type: "公益诈骗",
			region: "湖北省武汉市",
			date: "2023-04-22",
			image: "/static/img/cases/case_7.jpg"
		  },
		  {
			title: "“网络交友诱导赌博”诈骗案",
			type: "情感诈骗",
			region: "陕西省西安市",
			date: "2023-03-10",
			image: "/static/img/cases/case_8.jpg"
		  },
		  {
			title: "“虚假招聘”诈骗案",
			type: "招聘诈骗",
			region: "山东省青岛市",
			date: "2023-02-05",
			image: "/static/img/cases/case_9.jpg"
		  },
		  // 其他案例数据...
		];
		this.filteredCases = this.cases; // 初始显示全部
	  },
  
	  // 搜索处理
	  handleSearch() {
		this.filterCases();
	  },
	  handleCancel() {
		this.searchKeyword = "";
		this.filterCases();
	  },
  
	  // 筛选条件变化
	  bindRegionChange(e) {
		this.selectedRegion = this.regionOptions[e.detail.value];
		this.filterCases();
	  },
	  bindTypeChange(e) {
		this.selectedType = this.fraudTypes[e.detail.value];
		this.filterCases();
	  },
	  bindDateChange(e) {
		this.selectedDate = e.detail.value;
		this.filterCases();
	  },
  
	  // 综合筛选
	  filterCases() {
		this.filteredCases = this.cases.filter((item) => {
		  const keywordMatch = item.title.includes(this.searchKeyword) || 
							  item.desc?.includes(this.searchKeyword);
		  const regionMatch = !this.selectedRegion.value || 
							 item.region.includes(this.selectedRegion.value);
		  const typeMatch = !this.selectedType || 
							item.type === this.selectedType;
		  const dateMatch = !this.selectedDate || 
							item.date.startsWith(this.selectedDate);
		  return keywordMatch && regionMatch && typeMatch && dateMatch;
		});
	  },
  
	  // 跳转到详情页
	  navigateToDetail(caseItem) {
		uni.navigateTo({
		  url: `/pages/tabbar-3-detial/tabbar-3-release/tabbar-3-release?id=${caseItem.id}`,
		});
	  },
	},
  };
  </script>
  
  <style>
  .search-bg {
	min-height: 100vh;
	background: linear-gradient(180deg, #eaf4ff 0%, #f8faff 100%);
	display: flex;
	align-items: flex-start;
	justify-content: center;
	padding: 40rpx 0;
  }
  .search-container {
	width: 96vw;
	max-width: 700rpx;
  }
  .search-header {
	background: #fff;
	border-radius: 20rpx;
	padding: 32rpx 24rpx 24rpx 24rpx;
	margin-bottom: 24rpx;
	box-shadow: 0 8rpx 32rpx rgba(25, 118, 210, 0.10);
  }
  .search-bar {
	margin-bottom: 24rpx;
  }
  .filter-section {
	display: flex;
	justify-content: space-between;
	gap: 18rpx;
  }
  .filter-item {
	flex: 1;
  }
  .filter-label {
	display: block;
	font-size: 24rpx;
	color: #1976d2;
	margin-bottom: 8rpx;
	font-weight: 500;
  }
  .filter-picker {
	border: 2rpx solid #e3f0fd;
	border-radius: 12rpx;
	padding: 14rpx 18rpx;
	font-size: 26rpx;
	background: #f8faff;
	color: #1976d2;
	transition: border-color 0.2s;
  }
  .picker-text {
	color: #1976d2;
	font-size: 26rpx;
  }
  .search-results {
	background: #fff;
	border-radius: 20rpx;
	padding: 32rpx 24rpx 24rpx 24rpx;
	box-shadow: 0 8rpx 32rpx rgba(25, 118, 210, 0.10);
  }
  .empty-tip {
	text-align: center;
	padding: 40rpx;
	color: #888;
  }
  .case-card {
	margin-bottom: 24rpx;
	border-radius: 16rpx;
	overflow: hidden;
	box-shadow: 0 4rpx 16rpx rgba(25, 118, 210, 0.08);
	background: #f8faff;
	transition: box-shadow 0.2s;
  }
  .case-card:active {
	box-shadow: 0 2rpx 8rpx rgba(25, 118, 210, 0.12);
  }
  .case-image {
	width: 100%;
	height: 220rpx;
	object-fit: cover;
	display: block;
  }
  .case-info {
	padding: 20rpx 18rpx 16rpx 18rpx;
  }
  .case-title {
	font-size: 32rpx;
	font-weight: 700;
	color: #1976d2;
	margin-bottom: 10rpx;
  }
  .case-meta {
	display: flex;
	gap: 14rpx;
	margin-bottom: 2rpx;
	flex-wrap: wrap;
  }
  .case-tag {
	background: #e3f0fd;
	color: #1976d2;
	font-size: 22rpx;
	border-radius: 8rpx;
	padding: 4rpx 16rpx;
	font-weight: 500;
  }
  .case-tag-light {
	background: #f0f4fa;
	color: #5c9ded;
  }
  </style>