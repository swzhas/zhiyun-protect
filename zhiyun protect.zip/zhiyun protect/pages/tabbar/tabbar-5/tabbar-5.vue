<template>
  <view class="profile-bg">
    <view class="profile-container">
      <!-- 用户信息头部（保持原样式） -->
      <view class="profile-header">
        <image class="avatar" :src="userInfo.avatar || '/static/logo.png'" mode="aspectFill"></image>
        <view class="user-info">
          <text class="nickname">{{ userInfo.username || "未登录用户" }}</text>
          <text class="join-time">注册时间：{{ formatDate(userInfo.loginTime) }}</text>
        </view>
      </view>

      <!-- 原有功能菜单（完全保留） -->
      <view class="menu-section">
        <view class="menu-item" @click="navigateTo('browse-history')">
          <text class="icon"></text>
          <text class="title">浏览记录</text>
          <text class="arrow">›</text>
        </view>
        <view class="menu-item" @click="navigateTo('search-history')">
          <text class="icon"></text>
          <text class="title">搜索记录</text>
          <text class="arrow">›</text>
        </view>
        <view class="menu-item" @click="navigateTo('settings')">
          <text class="icon"></text>
          <text class="title">设置</text>
          <text class="arrow">›</text>
        </view>
      </view>

      <!-- 新增退出按钮（保持原按钮样式） -->
      <button class="logout-button" @click="handleLogout">退出登录</button>
    </view>
  </view>
</template>

<script>
import auth from '@/utils/auth'

export default {
  data() {
    return {
      userInfo: {}
    }
  },
  onShow() {
    this.loadUserData()
  },
  methods: {
    loadUserData() {
      const user = auth.getUser()
      this.userInfo = user || { username: "未登录用户" }
    },
    formatDate(timestamp) {
      if (!timestamp) return "2023-01-01"
      const date = new Date(timestamp)
      return `${date.getFullYear()}-${(date.getMonth()+1).toString().padStart(2,'0')}-${date.getDate().toString().padStart(2,'0')}`
    },
    navigateTo(page) {
      const routes = {
        "browse-history": "/pages/profile/browse-history",
        "search-history": "/pages/profile/search-history",
        "settings": "/pages/profile/settings",
      }
      uni.navigateTo({ url: routes[page] })
    },
    handleLogout() {
      uni.showModal({
        title: "提示",
        content: "确定要退出登录吗？",
        success: (res) => {
          if (res.confirm) {
            auth.clearUser()
            uni.reLaunch({ url: '/pages/login/login' })
          }
        }
      })
    }
  }
}
</script>

<style>
/* 完全保留原有样式 */
.profile-bg {
  min-height: 100vh;
  background: linear-gradient(180deg, #eaf4ff 0%, #f8faff 100%);
  display: flex;
  align-items: flex-start;
  justify-content: center;
  padding: 60rpx 0 40rpx 0;
}
.profile-container {
  width: 92vw;
  max-width: 1000rpx;
}
.profile-header {
  display: flex;
  align-items: center;
  padding: 36rpx 20rpx 36rpx 20rpx;
  background: #fff;
  border-radius: 32rpx;
  margin-bottom: 28rpx;
  box-shadow: 0 6rpx 32rpx rgba(25, 118, 210, 0.08);
}
.avatar {
  width: 120rpx;
  height: 120rpx;
  border-radius: 50%;
  margin-right: 24rpx;
  border: none;
  box-shadow: 0 2rpx 8rpx rgba(25,118,210,0.06);
}
.user-info {
  flex: 1;
}
.nickname {
  font-size: 36rpx;
  font-weight: 700;
  color: #1976d2;
  display: block;
  margin-bottom: 10rpx;
  letter-spacing: 1rpx;
}
.join-time {
  font-size: 24rpx;
  color: #5c9ded;
}
.menu-section {
  background: #fff;
  border-radius: 32rpx;
  padding: 0 20rpx;
  box-shadow: 0 6rpx 32rpx rgba(25, 118, 210, 0.08);
}
.menu-item {
  height: 100rpx;
  display: flex;
  align-items: center;
  border-bottom: 1rpx solid #f0f0f0;
}
.menu-item:last-child {
  border-bottom: none;
}
.title {
  flex: 1;
  font-size: 30rpx;
  color: #333;
}
.arrow {
  color: #999;
  font-size: 40rpx;
}
.logout-button {
  margin-top: 40rpx;
  background: #fff;
  color: #1976d2;
  border: 1rpx solid #1976d2;
  border-radius: 16rpx;
  height: 80rpx;
  line-height: 80rpx;
  font-size: 32rpx;
  box-shadow: 0 4rpx 16rpx rgba(25, 118, 210, 0.1);
}
</style>