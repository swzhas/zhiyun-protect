<template>
	<view class="container">
	  <view class="header">
		<text class="title">最新诈骗新闻</text>
		<text class="subtitle">提高警惕，远离诈骗</text>
	  </view>
	  <view class="case-list">
		<view v-for="(caseItem, index) in cases" :key="index" class="case-card" @click="showDetail(index)">
		  <view class="case-image-wrapper">
			<image :src="caseItem.image" class="case-image" mode="aspectFill"></image>
			<view class="case-image-overlay"></view>
			<text class="case-title-overlay">{{ caseItem.title }}</text>
		  </view>
		  <view class="case-info">
			<view class="case-meta">
			  <text class="case-tag">{{ caseItem.type }}</text>
			  <text class="case-tag case-tag-light">{{ caseItem.region }}</text>
			  <text class="case-tag case-tag-light">{{ caseItem.date }}</text>
			</view>
			<text class="case-desc">{{ caseItem.desc }}</text>
		  </view>
		</view>
	  </view>
	  <!-- 案件详情弹窗 -->
	  <view v-if="showPopup" class="popup-mask" @click.self="closeDetail">
		<view class="popup-detail">
		  <view class="popup-image-wrapper">
			<image :src="selectedCase.image" class="popup-image" mode="aspectFill"></image>
			<view class="popup-type-tag">{{ selectedCase.type }}</view>
		  </view>
		  <view class="popup-content">
			<text class="popup-title">{{ selectedCase.title }}</text>
			<view class="popup-meta">
			  <text class="popup-meta-item">地区：{{ selectedCase.region }}</text>
			  <text class="popup-meta-item">日期：{{ selectedCase.date }}</text>
			</view>
			<view class="popup-detail-body">
			  <view v-for="(para, idx) in selectedCase.detail" :key="idx" class="popup-detail-para">
				<text>{{ para }}</text>
			  </view>
			  <view v-if="selectedCase.detailImages && selectedCase.detailImages.length" class="popup-detail-images">
				<image v-for="(img, i) in selectedCase.detailImages" :key="i" :src="img" class="popup-detail-img" mode="aspectFill"></image>
			  </view>
			</view>
		  </view>
		  <view class="popup-close" @click="closeDetail">×</view>
		</view>
	  </view>
	</view>
  </template>
  
  <script>
  export default {
	data() {
	  return {
		cases: [
		  {
			title: "“高回报投资”诈骗案",
			type: "投资诈骗",
			region: "广东省深圳市",
			date: "2023-10-15",
			desc: "骗子以高额回报为诱饵，诱导受害者投资虚假项目，卷款跑路。",
			image: "/static/img/cases/case_1.jpg",
			detail: [
			  "受害人接到自称某投资平台工作人员的电话，称有高额回报的理财项目，承诺本金安全、收益稳定。",
			  "在对方的引导下，受害人下载了虚假投资APP，并多次转账投入资金。",
			  "当受害人要求提现时，对方以各种理由拖延，最终平台无法登录，工作人员失联。",
			  "警方提醒：高收益伴随高风险，切勿轻信陌生投资渠道。"
			],
			detailImages: [
			  "/static/img/cases/case_1_1.jpg",
			  "/static/img/cases/case_1_2.jpg"
			]
		  },
		  {
			title: "“冒充公检法”诈骗案",
			type: "电信诈骗",
			region: "北京市朝阳区",
			date: "2023-09-20",
			desc: "骗子冒充警察，谎称受害者涉嫌洗钱，要求转账至“安全账户”。",
			image: "/static/img/cases/case_2.jpg"
		  },
		  {
			title: "“虚假中奖”诈骗案",
			type: "网络诈骗",
			region: "上海市浦东区",
			date: "2023-08-05",
			desc: "受害者收到“中奖短信”，点击链接后银行卡被盗刷。",
			image: "/static/img/cases/case_3.jpg"
		  },
		  {
			title: "“刷单兼职”诈骗案",
			type: "兼职诈骗",
			region: "浙江省杭州市",
			date: "2023-07-12",
			desc: "骗子以“轻松赚钱”为名，诱导受害者垫付资金后消失。",
			image: "/static/img/cases/case_4.jpg"
		  },
		  {
			title: "“虚假贷款”诈骗案",
			type: "金融诈骗",
			region: "四川省成都市",
			date: "2023-06-30",
			desc: "受害者申请贷款时被要求支付“手续费”，转账后对方失联。",
			image: "/static/img/cases/case_5.jpg"
		  },
		  {
			title: "“冒充客服退款”诈骗案",
			type: "电商诈骗",
			region: "江苏省南京市",
			date: "2023-05-18",
			desc: "骗子冒充电商客服，以“商品质量问题”为由诱导受害者提供银行卡信息。",
			image: "/static/img/cases/case_6.jpg"
		  },
		  {
			title: "“虚假慈善募捐”诈骗案",
			type: "公益诈骗",
			region: "湖北省武汉市",
			date: "2023-04-22",
			desc: "骗子伪造慈善机构，利用灾区募捐名义骗取善款。",
			image: "/static/img/cases/case_7.jpg"
		  },
		  {
			title: "“网络交友诱导赌博”诈骗案",
			type: "情感诈骗",
			region: "陕西省西安市",
			date: "2023-03-10",
			desc: "骗子通过社交平台结识受害者，诱导其参与虚假赌博网站。",
			image: "/static/img/cases/case_8.jpg"
		  },
		  {
			title: "“虚假招聘”诈骗案",
			type: "招聘诈骗",
			region: "山东省青岛市",
			date: "2023-02-05",
			desc: "受害者应聘高薪工作，被要求缴纳“培训费”后公司消失。",
			image: "/static/img/cases/case_9.jpg"
		  },
		  {
			title: "“冒充学校收费”诈骗案",
			type: "教育诈骗",
			region: "湖南省长沙市",
			date: "2023-01-15",
			desc: "骗子冒充学校老师，以“学费补缴”为由骗取家长转账。",
			image: "/static/img/cases/case_10.jpg",
			detail: [
			  "家长接到自称学校老师的电话，称孩子学费未缴清，需尽快补缴，否则影响正常上课。",
			  "对方通过伪造的学校公章、收据等取得家长信任，要求将学费转账至指定账户。",
			  "事后家长联系学校核实时，发现被骗。",
			  "警方提醒：涉及转账汇款务必通过官方渠道核实，谨防冒充身份诈骗。"
			],
			detailImages: [
			  "/static/img/cases/case_10_1.jpg"
			]
		  }
		],
		showPopup: false,
		selectedCase: {}
	  };
	},
	methods: {
	  showDetail(index) {
		this.selectedCase = this.cases[index];
		this.showPopup = true;
	  },
	  closeDetail() {
		this.showPopup = false;
	  }
	}
  };
  </script>
  
  <style>
  .container {
	padding: 32rpx 16rpx 16rpx 16rpx;
	background: linear-gradient(180deg, #eaf4ff 0%, #f8faff 100%);
	min-height: 100vh;
  }
  .header {
	margin-bottom: 36rpx;
	text-align: center;
  }
  .title {
	font-size: 44rpx;
	font-weight: 700;
	color: #1976d2;
	letter-spacing: 2rpx;
  }
  .subtitle {
	font-size: 26rpx;
	color: #5c9ded;
	margin-top: 8rpx;
	letter-spacing: 1rpx;
  }
  .case-list {
	display: flex;
	flex-direction: column;
	gap: 32rpx;
  }
  .case-card {
	background: #fff;
	border-radius: 20rpx;
	overflow: hidden;
	box-shadow: 0 6rpx 24rpx rgba(25, 118, 210, 0.08);
	transition: box-shadow 0.2s;
  }
  .case-card:active {
	box-shadow: 0 2rpx 8rpx rgba(25, 118, 210, 0.12);
  }
  .case-image-wrapper {
	position: relative;
	width: 100%;
	height: 240rpx;
	overflow: hidden;
  }
  .case-image {
	width: 100%;
	height: 240rpx;
	object-fit: cover;
	display: block;
  }
  .case-image-overlay {
	position: absolute;
	left: 0; right: 0; top: 0; bottom: 0;
	background: linear-gradient(180deg, rgba(25,118,210,0.32) 0%, rgba(25,118,210,0.08) 100%);
	z-index: 1;
  }
  .case-title-overlay {
	position: absolute;
	left: 24rpx;
	bottom: 18rpx;
	z-index: 2;
	color: #fff;
	font-size: 32rpx;
	font-weight: 600;
	text-shadow: 0 2rpx 8rpx rgba(25,118,210,0.18);
  }
  .case-info {
	padding: 24rpx 20rpx 20rpx 20rpx;
  }
  .case-meta {
	display: flex;
	gap: 16rpx;
	margin-bottom: 12rpx;
	flex-wrap: wrap;
  }
  .case-tag {
	background: #e3f0fd;
	color: #1976d2;
	font-size: 22rpx;
	border-radius: 8rpx;
	padding: 4rpx 16rpx;
	font-weight: 500;
  }
  .case-tag-light {
	background: #f0f4fa;
	color: #5c9ded;
  }
  .case-desc {
	font-size: 26rpx;
	color: #444;
	line-height: 1.7;
	margin-top: 2rpx;
  }
  /* 弹窗样式 */
  .popup-mask {
	position: fixed;
	left: 0; top: 0; right: 0; bottom: 0;
	background: rgba(0,0,0,0.25);
	z-index: 1000;
	display: flex;
	align-items: center;
	justify-content: center;
  }
  .popup-detail {
	background: #fff;
	border-radius: 20rpx;
	width: 90vw;
	max-width: 600rpx;
	box-shadow: 0 8rpx 32rpx rgba(25, 118, 210, 0.12);
	overflow: hidden;
	position: relative;
	animation: popupIn 0.2s;
  }
  @keyframes popupIn {
	from { transform: scale(0.95); opacity: 0; }
	to { transform: scale(1); opacity: 1; }
  }
  .popup-image-wrapper {
	position: relative;
	width: 100%;
	height: 240rpx;
	overflow: hidden;
  }
  .popup-image {
	width: 100%;
	height: 240rpx;
	object-fit: cover;
	display: block;
  }
  .popup-type-tag {
	position: absolute;
	left: 24rpx;
	bottom: 18rpx;
	background: #1976d2;
	color: #fff;
	font-size: 26rpx;
	font-weight: 600;
	border-radius: 12rpx;
	padding: 8rpx 28rpx;
	box-shadow: 0 2rpx 8rpx rgba(25,118,210,0.12);
	z-index: 2;
	letter-spacing: 2rpx;
  }
  .popup-content {
	padding: 32rpx 24rpx 24rpx 24rpx;
  }
  .popup-title {
	font-size: 34rpx;
	font-weight: 700;
	color: #1976d2;
	margin-bottom: 16rpx;
	display: block;
  }
  .popup-meta {
	display: flex;
	gap: 24rpx;
	margin-bottom: 16rpx;
	flex-wrap: wrap;
  }
  .popup-meta-item {
	font-size: 22rpx;
	color: #5c9ded;
  }
  .popup-desc {
	font-size: 26rpx;
	color: #444;
	line-height: 1.8;
	margin-top: 8rpx;
	display: block;
  }
  .popup-close {
	position: absolute;
	top: 16rpx;
	right: 24rpx;
	font-size: 40rpx;
	color: #1976d2;
	font-weight: bold;
	cursor: pointer;
	z-index: 10;
	user-select: none;
  }
  .popup-detail-body {
	margin-top: 12rpx;
  }
  .popup-detail-para {
	font-size: 26rpx;
	color: #444;
	line-height: 1.8;
	margin-bottom: 10rpx;
  }
  .popup-detail-images {
	display: flex;
	flex-wrap: wrap;
	gap: 16rpx;
	margin-top: 12rpx;
  }
  .popup-detail-img {
	width: 44vw;
	max-width: 220rpx;
	height: 140rpx;
	border-radius: 10rpx;
	object-fit: cover;
	box-shadow: 0 2rpx 8rpx rgba(25,118,210,0.10);
  }
  </style>
