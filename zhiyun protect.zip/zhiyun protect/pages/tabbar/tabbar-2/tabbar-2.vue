<template>
	<view class="consult-container">
	  <!-- 顶部品牌区 -->
	  <view class="brand-header">
		<image src="/static/img/shield-icon.png" class="brand-logo" />
		<text class="brand-title">智云防诈</text>
		<text class="brand-subtitle">AI 安全顾问</text>
	  </view>
  
	  <!-- 功能引导区 -->
	  <view class="feature-guide">
		<view class="guide-item" @click="quickQuestion('最新诈骗手法')">
		  <image src="/static/avatar-default.png" class="guide-icon" />
		  <text>诈骗趋势</text>
		</view>
		<view class="guide-item" @click="quickQuestion('报警流程')">
		  <image src="/static/avatar-default.png" class="guide-icon" />
		  <text>紧急求助</text>
		</view>
		<view class="guide-item" @click="navigateToRecord">
		  <image src="/static/avatar-default.png" class="guide-icon" />
		  <text>我的记录</text>
		</view>
	  </view>
  
	  <!-- 聊天主区域 -->
	  <view class="chat-main">
		<!-- 默认引导 -->
		<view v-if="messages.length === 0" class="welcome-guide">
		  <image src="/static/img/release.png" class="welcome-avatar" />
		  <text class="welcome-text">您好！我是防诈助手，请问有什么可以帮您？</text>
		  <view class="quick-questions">
			<text @click="quickQuestion('如何识别钓鱼网站？')">钓鱼网站识别</text>
			<text @click="quickQuestion('被骗后第一步做什么？')">应急处理</text>
		  </view>
		</view>
  
		<!-- 消息列表 -->
		<view v-for="(msg, index) in messages" :key="index" class="message-bubble" :class="msg.isUser ? 'user-bubble' : 'bot-bubble'">
		  {{ msg.content }}
		</view>
	  </view>
  
	  <!-- 输入区 -->
	  <view class="input-box">
		<input
		  v-model="inputMessage"
		  placeholder="输入您的问题..."
		  class="input-field"
		  @confirm="sendMessage"
		/>
		<button @click="sendMessage" class="send-button">
		  <image src="/static/img/send-icon.png" class="send-icon" />
		</button>
	  </view>
	</view>
  </template>
  <script>
  export default {
	data() {
	  return {
		messages: [],
		inputMessage: "",
	  };
	},
	methods: {
	  sendMessage() {
		if (this.inputMessage.trim()) {
		  this.messages.push({ 
			content: this.inputMessage, 
			isUser: true 
		  });
		  this.simulateReply();
		  this.inputMessage = "";
		}
	  },
	  simulateReply() {
		setTimeout(() => {
		  this.messages.push({
			content: "已收到您的咨询，建议保留所有证据并立即报警。",
			isUser: false
		  });
		}, 800);
	  },
	  quickQuestion(question) {
		this.inputMessage = question;
		this.sendMessage();
	  },
	  navigateToRecord() {
		uni.navigateTo({ url: "/pages/tabbar/tabbar-3/tabbar-3" });
	  }
	}
  };
  </script>
  <style>
  /* 基础样式 */
  .consult-container {
	height: 100vh;
	display: flex;
	flex-direction: column;
	background-color: #f8faff;
	padding: 20rpx;
  }
  
  /* 品牌头 */
  .brand-header {
	text-align: center;
	padding: 30rpx 0;
  }
  .brand-logo {
	width: 100rpx;
	height: 100rpx;
	margin-bottom: 10rpx;
  }
  .brand-title {
	font-size: 36rpx;
	font-weight: bold;
	color: #1a73e8;
	display: block;
  }
  .brand-subtitle {
	font-size: 24rpx;
	color: #5f6368;
  }
  
  /* 功能引导 */
  .feature-guide {
	display: flex;
	justify-content: space-around;
	margin: 20rpx 0;
  }
  .guide-item {
	display: flex;
	flex-direction: column;
	align-items: center;
	width: 30%;
  }
  .guide-icon {
	width: 60rpx;
	height: 60rpx;
	margin-bottom: 10rpx;
  }
  
  /* 聊天区 */
  .chat-main {
	flex: 1;
	overflow-y: auto;
	padding: 20rpx;
	margin-bottom: 20rpx;
  }
  .welcome-guide {
	text-align: center;
	margin-top: 50rpx;
  }
  .welcome-avatar {
	width: 120rpx;
	height: 120rpx;
	margin-bottom: 20rpx;
  }
  .welcome-text {
	color: #666;
	margin-bottom: 30rpx;
	display: block;
  }
  .quick-questions text {
	display: inline-block;
	margin: 0 15rpx;
	padding: 10rpx 20rpx;
	background: #e8f0fe;
	border-radius: 20rpx;
	color: #1a73e8;
  }
  
  /* 消息气泡 */
  .message-bubble {
	max-width: 70%;
	padding: 16rpx 24rpx;
	border-radius: 18rpx;
	margin-bottom: 20rpx;
	line-height: 1.4;
  }
  .user-bubble {
	background: #1a73e8;
	color: white;
	margin-left: auto;
	border-bottom-right-radius: 4rpx;
  }
  .bot-bubble {
	background: white;
	border: 1rpx solid #e0e0e0;
	margin-right: auto;
	border-bottom-left-radius: 4rpx;
  }
  
  /* 输入区 */
  .input-box {
	display: flex;
	padding: 15rpx;
	background: white;
	border-radius: 50rpx;
	box-shadow: 0 2rpx 10rpx rgba(0,0,0,0.05);
  }
  .input-field {
	flex: 1;
	padding: 0 20rpx;
  }
  .send-button {
	width: 80rpx;
	height: 80rpx;
	background: #1a73e8;
	border-radius: 50%;
	display: flex;
	justify-content: center;
	align-items: center;
  }
  .send-icon {
	width: 40rpx;
	height: 40rpx;
  }
  </style>