<template>
	<view class="publish-bg">
	  <view class="publish-card">
		<!-- 修改标题和说明 -->
		<view class="header">
		  <text class="title">反诈备忘录</text>
		  <text class="subtitle">仅存储于您的设备，他人不可见</text>
		</view>
  
		<view class="form-section">
		  <!-- 案件标题改为记录标题 -->
		  <view class="form-item">
			<text class="label">记录标题</text>
			<input 
			  v-model="form.title" 
			  placeholder="例如：虚假投资平台记录" 
			  class="input" 
			/>
		  </view>
  
		  <!-- 案件类型改为事件类型 -->
		  <view class="form-item">
			<text class="label">事件类型</text>
			<picker @change="bindTypeChange" :range="recordTypes" class="picker">
			  <view class="picker-text">{{ form.type || '选择类型' }}</view>
			</picker>
		  </view>
				<!-- 省市区选择 -->
				<view class="form-item">
					<text class="label">发生地区</text>
					<picker
						mode="multiSelector"
						:range="regionColumns"
						:range-key="'name'"
						@change="bindRegionChange"
						@columnchange="bindRegionColumnChange"
						class="picker"
					>
						<view class="picker-text">
							{{ form.province || '省' }} - {{ form.city || '市' }} - {{ form.district || '区' }}
						</view>
					</picker>
				</view>
			<!-- 保留时间选择 -->
			<view class="form-item">
          <text class="label">发生时间</text>
          <picker mode="date" @change="bindDateChange" class="picker">
            <view class="picker-text">{{ form.date || '选择时间' }}</view>
          </picker>
        </view>

        <!-- 详细描述改为事件记录 -->
        <view class="form-item">
          <text class="label">详细记录</text>
          <textarea
            v-model="form.desc"
            placeholder="请详细记录诈骗过程（账号、金额、对话等关键信息）..."
            class="textarea"
          ></textarea>
        </view>

        <!-- 图片上传保留但修改说明 -->
        <view class="form-item">
          <text class="label">证据截图（可选）</text>
          <view class="upload-area" @click="chooseImage">
            <image v-if="form.image" :src="form.image" class="preview-image" mode="aspectFill"></image>
            <view v-else class="upload-placeholder">
              <text>点击上传截图证据</text>
            </view>
          </view>
        </view>

        <!-- 修改按钮文字和功能 -->
        <button @click="saveRecord" class="submit-button">保存记录</button>
      </view>

      <!-- 修改成功提示 -->
      <uni-popup ref="popup" type="message">
        <uni-popup-message 
          type="success" 
          message="记录已保存到本地" 
          :duration="2000"
        ></uni-popup-message>
      </uni-popup>
    </view>
  </view>
</template>

<script>
import regionData from "@/utils/region-date.js";

export default {
	data() {
		return {
			form: {
				title: "",
				type: "",
				province: "",
				city: "",
				district: "",
				date: "",
				amount: "",
				desc: "",
				image: "",
			},
			fraudTypes: [
				"投资诈骗",
				"电信诈骗",
				"网络诈骗",
				"兼职诈骗",
				"金融诈骗",
				"情感诈骗",
			],
			regionData: [], // 原始省市区数据
			regionColumns: [[], [], []], // 三级联动数据：省、市、区
		};
	},
	mounted() {
		this.regionData = regionData;
		this.initRegionColumns();
	},
	methods: {
		// 初始化地区数据
		initRegionColumns() {
			// 第一列：省份
			this.regionColumns[0] = this.regionData.map(item => ({ name: item.name }));

			// 第二列：默认第一个省份的城市
			if (this.regionData[0]?.children) {
				this.regionColumns[1] = this.regionData[0].children.map(item => ({ name: item.name }));
			}

			// 第三列：默认第一个城市的区县
			if (this.regionData[0]?.children[0]?.children) {
				this.regionColumns[2] = this.regionData[0].children[0].children.map(item => ({ name: item.name }));
			}
		},

		// 地区列变化时更新数据
		bindRegionColumnChange(e) {
			const { column, value } = e.detail;

			if (column === 0) {
				// 省份变化，更新城市和区县
				const cities = this.regionData[value]?.children || [];
				this.regionColumns[1] = cities.map(item => ({ name: item.name }));
				this.regionColumns[2] = cities[0]?.children?.map(item => ({ name: item.name })) || [];
			} else if (column === 1) {
				// 城市变化，更新区县
				const provinceIdx = this.regionColumns[0].findIndex(
					item => item.name === this.form.province
				);
				const districts = this.regionData[provinceIdx]?.children[value]?.children || [];
				this.regionColumns[2] = districts.map(item => ({ name: item.name }));
			}
		},

		// 地区选择完成
		bindRegionChange(e) {
			const [provinceIdx, cityIdx, districtIdx] = e.detail.value;
			this.form.province = this.regionColumns[0][provinceIdx]?.name || "";
			this.form.city = this.regionColumns[1][cityIdx]?.name || "";
			this.form.district = this.regionColumns[2][districtIdx]?.name || "";
		},

		// 选择案件类型
		bindTypeChange(e) {
			this.form.type = this.fraudTypes[e.detail.value];
		},

		// 选择图片
		chooseImage() {
			uni.chooseImage({
				count: 1,
				sizeType: ["compressed"],
				success: (res) => {
					this.form.image = res.tempFilePaths[0];
				},
			});
		},

		// 选择案件时间
		bindDateChange(e) {
			this.form.date = e.detail.value;
		},

		saveRecord() {
      if (!this.form.title || !this.form.desc) {
        uni.showToast({ title: "请填写标题和详细记录", icon: "none" })
        return
      }

      const record = {
        ...this.form,
        id: Date.now(),
        createdAt: new Date().toISOString()
      }

      // AES加密存储
      const encrypted = CryptoJS.AES.encrypt(
        JSON.stringify(record),
        uni.getSystemInfoSync().deviceId
      ).toString()

      uni.setStorageSync(`private_record_${record.id}`, encrypted)
      this.$refs.popup.open()
      this.resetForm()
    },

		// 重置表单
		resetForm() {
			this.form = {
				title: "",
				type: "",
				province: "",
				city: "",
				district: "",
				date: "",
				amount: "",
				desc: "",
				image: "",
			};
		},
	},
};
</script>

<style>
.privacy-notice {
  margin-top: 40rpx;
  padding: 20rpx;
  background-color: #f0f7ff;
  border-radius: 12rpx;
  text-align: center;
  font-size: 24rpx;
  color: #5c9ded;
}
.publish-bg {
	min-height: 100vh;
	background: linear-gradient(180deg, #eaf4ff 0%, #f8faff 100%);
	display: flex;
	align-items: center;
	justify-content: center;
	padding: 40rpx 0;
}
.publish-card {
	background: #fff;
	border-radius: 24rpx;
	box-shadow: 0 8rpx 32rpx rgba(25, 118, 210, 0.10);
	padding: 48rpx 36rpx 36rpx 36rpx;
	width: 92vw;
	max-width: 600rpx;
	display: flex;
	flex-direction: column;
	align-items: stretch;
}
.header {
	margin-bottom: 30rpx;
	text-align: center;
}
.title {
	font-size: 38rpx;
	font-weight: 700;
	color: #1976d2;
	letter-spacing: 2rpx;
}
.subtitle {
	font-size: 26rpx;
	color: #5c9ded;
	margin-top: 8rpx;
	letter-spacing: 1rpx;
}
.form-section {
	background: none;
	padding: 0;
	border-radius: 0;
	box-shadow: none;
}
.form-item {
	margin-bottom: 32rpx;
}
.label {
	display: block;
	font-size: 28rpx;
	color: #1976d2;
	margin-bottom: 10rpx;
	font-weight: 500;
}
.input,
.textarea {
	font-size: 28rpx;
	border: 2rpx solid #e3f0fd;
	border-radius: 12rpx;
	padding: 18rpx 20rpx;
	background: #f8faff;
	outline: none;
	transition: border-color 0.2s;
}
.input:focus,
.textarea:focus {
	border-color: #1976d2;
}
.textarea {
	min-height: 160rpx;
	resize: none;
}
.picker {
	width: 100%;
}
.picker-text {
	font-size: 28rpx;
	color: #1976d2;
	background: #f8faff;
	border: 2rpx solid #e3f0fd;
	border-radius: 12rpx;
	padding: 18rpx 20rpx;
	margin-top: 2rpx;
	transition: border-color 0.2s;
}
.upload-area {
	border: 2rpx dashed #5c9ded;
	border-radius: 12rpx;
	padding: 24rpx;
	background: #f8faff;
	display: flex;
	align-items: center;
	justify-content: center;
	min-height: 120rpx;
	cursor: pointer;
	transition: border-color 0.2s, background 0.2s;
}
.upload-area:active {
	border-color: #1976d2;
	background: #e3f0fd;
}
.upload-placeholder {
	color: #5c9ded;
	font-size: 28rpx;
}
.preview-image {
	width: 180rpx;
	height: 120rpx;
	border-radius: 12rpx;
	object-fit: cover;
	box-shadow: 0 2rpx 8rpx rgba(25,118,210,0.10);
}
.submit-button {
	margin-top: 18rpx;
	background: linear-gradient(90deg, #1976d2 0%, #1e90ff 100%);
	color: #fff;
	font-size: 32rpx;
	font-weight: 600;
	border: none;
	border-radius: 16rpx;
	box-shadow: 0 4rpx 16rpx rgba(25, 118, 210, 0.10);
	padding: 20rpx 0;
	letter-spacing: 2rpx;
	transition: background 0.2s;
}
.submit-button:active {
	background: #1565c0;
}
</style>